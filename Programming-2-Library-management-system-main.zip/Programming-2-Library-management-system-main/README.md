# Programming 2-Library management system
 A typical Library management system
 
 -multiple objects
 -e.g students..books..etc
 -wmust have authentication
 -tracking of books  or  loan progress  indicating the return date etc.
