public interface searchBook {

    //interface is implemented in Customer class




    void searchBook();
}

