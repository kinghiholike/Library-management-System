import java.sql.*;

public interface Dao {
    Connection getConnect();
}
